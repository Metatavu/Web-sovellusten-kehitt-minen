import React, { FC } from "react";
import { useNavigate } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
}

type Props = {
    todoLista: TodoAsia[];
}

/**
 * MuokkausScreen komponentti
 */
const MuokkausScreen: FC<Props> = ({
    todoLista
}) => {
    const navigoi = useNavigate()

    return (
        <div>
            <h1>Muokataan asioita</h1>
        </div>
    )
}

export default MuokkausScreen;