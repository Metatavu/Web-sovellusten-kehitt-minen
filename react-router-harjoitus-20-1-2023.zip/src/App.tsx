import React, { useState, FC } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { v4 as uuid } from "uuid";
import ListaScreen from "./screens/ListaScreen";
import MuokkausScreen from "./screens/MuokkausScreen";
import PoistoScreen from "./screens/PoistoScreen";


interface TodoAsia {
  id: string;
  nimi: string;
}

/**
 * App komponentti
 */
const App: FC = () => {
  const [ todoLista, setTodoLista ] = useState<TodoAsia[]>([
    {
      id: uuid(),
      nimi: "Käy kaupassa",
    },
    {
      id: uuid(),
      nimi: "Koiran lenkitys",
    },
    {
      id: uuid(),
      nimi: "Auton huolto",
    }
  ]);

  return (
    <div>
      <h1>Todo-lista</h1>
      <BrowserRouter>
        <Routes>
          <Route 
            path="/"
            element={ <ListaScreen todoLista={ todoLista } /> }
          />
          <Route 
            path="/muokkaa/:id"
            element={ <MuokkausScreen todoLista={ todoLista } /> }
          />
          <Route 
            path="/poista/:id"
            element={ <PoistoScreen todoLista={ todoLista } setTodoLista={ setTodoLista }/> }
          />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App;