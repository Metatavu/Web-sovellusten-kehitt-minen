/**
 * Komponentin ominaisuudet
 */
interface Props {
    children: React.ReactNode;
}

/**
 * Lista komponentti
 */
const Lista: React.FC<Props> = ({ children }) => {
    return (
        <ul style={{ width: "200px" }}>
            { children }
        </ul>
    )
}

export default Lista;