import express, { Express } from "express"
import path from "path";

/**
 * Alustetaan Express-sovellus
 */
const palvelin: Express = express();

/**
 * Määritellään portti, mitä palvelin kuuntelee
 */
const portti = 3005;

/**
 * Määritetään palvelin käyttämään "static"-kansiota, kun ollaan sovelluksen juuressa ("/").
 */
palvelin.use("/", express.static(path.join(__dirname,"static")));

/**
 * Esimerkki get-metodista, palvelin palauttaa vastauksen "Heippa Maailma" kun selaimella navigoidaan polkuun
 * "/heippa"
 */
palvelin.get("/heippa", (req, res) => {
    res.send("Heippa Maailma");
});

/**
 * Määritetään palvelin kuuntelemaan määriteltyä porttia
 * Tämän jälkeen palvelin on valmis vastaanottamaan kutsuja (get, post, put jne..)
 */
palvelin.listen(portti, () => {
    console.log(`Palvelin kuuntelee porttia: ${portti}`)
});