import { Tehtava } from "../tyypit";
import path from "path"
import { readFile, writeFile } from "fs/promises";
import { v4 as uuid } from "uuid";

export default class TehtavalistaModel {
    /**
     * Private (luokan sisällä käytettävät) ominaisuudet
     */

    // Alustetaan tehtävälista
    private tehtavaLista: Tehtava[] = [];
    // Luodaan polku datan varastona käytettävään tiedostoon, näin polkua ei tarvitse aina kirjoittaa uudelleen
    private tiedostoPolku: string = path.join(path.resolve(__dirname, ".."), "tehtavalista.json");

    constructor() {
        this.lataaTiedosto();
    }

    /**
     * Hakee tehtävälistan
     * 
     * @returns tehtävälista
     */
    public haeTehtavalista() {
        return this.tehtavaLista;
    }

    /**
     * Luo uuden tehtävän tehtävälistaan
     * 
     * @param nimi 
     * @returns uuden tehtävän
     */
    public async luoTehtava(nimi: string) {
        if(this.tarkistaOnkoNimiKonflikti(nimi)) {
            throw {
                statusKoodi: 409,
                virheViesti: `Tehtävälista sisältää jo tehtävän nimellä ${nimi}`
            }
        }

        const uusiTehtava: Tehtava = {
            id: uuid(),
            nimi: nimi,
            tila: "Tekemättä"
        }

        this.tehtavaLista.push(uusiTehtava);
        this.tallennaTiedosto();

        return uusiTehtava;
    }

    /**
     * Poista tehtävä
     */
    public async poistaTehtava(id: string) {
        this.tehtavaLista = this.tehtavaLista.filter(tehtava => tehtava.id !== id)

        await this.tallennaTiedosto();
    }

    /**
     * Muokkaa tehtävä
     */
    public async muokkaaTehtava(id: string, tehtava: Tehtava) {

        const loydettyTehtava = this.etsiTehtava(id);

        const muokattuTehtava: Tehtava = {
            ...loydettyTehtava,
            ...tehtava
        }

        const indeksi = this.tehtavaLista.indexOf(loydettyTehtava);

        this.tehtavaLista.splice(indeksi, 1, muokattuTehtava);

        await this.tallennaTiedosto();

        return muokattuTehtava;

    }

    /**
     * Etsi yksittäisen tehtävän tehtävälistalta
     */
    public etsiTehtava(id: string) {
        const loydettyTehtava = this.tehtavaLista.find(tehtava => tehtava.id === id);

        if(!loydettyTehtava) {
            throw {
                statusKoodi: 400,
                virheViesti: `Tehtävää id:llä ${id} ei löytynyt`
            }
        }

        return loydettyTehtava;
    }

    /**
     * Tarkistaa onko nimi jo käytössä, palauttaa true, jos on
     * 
     * @param nimi 
     * @returns true tai false
     */
    private tarkistaOnkoNimiKonflikti = (nimi: string) => {
        return this.tehtavaLista.some(tehtavaLista => tehtavaLista.nimi === nimi);
    }

    /**
     * Tallentaa uuden tehtävälistan tiedostoon
     */
    private async tallennaTiedosto() {
        await writeFile(this.tiedostoPolku, JSON.stringify(this.tehtavaLista, null, 2))
    }

    /**
     * Lataa tehtavalista.json-tiedoston sisällön muuttujaan
     * Jos tiedosto tällä nimellä ei löydy, luo sellaisen
     */
    private async lataaTiedosto() {
        const tiedostoBuffer = await readFile(this.tiedostoPolku, { flag: "a+" });

        if(!tiedostoBuffer.toJSON().data.length) {
            this.tehtavaLista = [];
        } else {
            this.tehtavaLista = JSON.parse(tiedostoBuffer.toString());
        }
    }
}