import express, { Router, Request, Response } from "express";
import TehtavalistaModel from "../model";

/**
 * Alustetaan reititin
 */
export const reititin: Router = express.Router();

/**
 * Konstruktoidaan Tehtavalista-luokan instanssi
 */
const tehtavalistaModel = new TehtavalistaModel

/**
 * Juuripolku palauttaa tehtävän listan asiat
 */
reititin.get("/", (request: Request, response: Response) => {
    try {
        const tehtavalista = tehtavalistaModel.haeTehtavalista();

        return response.status(200).json(tehtavalista);
    } catch (error: any) {
        return response.status(error.statusCode).json(error);
    }
});

/**
 * Tämä polku käsittelee POST-pyynnöt eli uuden tehtävän lisäämisen
 */
reititin.post("/", async (request: Request, response: Response) => {
    try {
        const { nimi } = request.body;

        if(!nimi) {
            throw {
                statusKoodi: 400,
                virheViesti: "Puuttuu ominaisuus: nimi"
            }
        }

        const luotuTehtavalista = await tehtavalistaModel.luoTehtava(nimi);

        return response.status(201).json(luotuTehtavalista);

    } catch (error: any) {
        return response.status(error.statusCode).json(error);
    }
});

/**
 * Tämä polku käsittelee DELETE-pyynnöt eli tehtävän poistamisen
 */
reititin.delete("/:id", async (request: Request, response: Response) => {
    try {

        const { id } = request.params;

        await tehtavalistaModel.poistaTehtava(id);

        return response.status(204).json();

    } catch (error: any) {
        return response.status(error.statusCode).json(error);
    }
});

/**
 * Tämä polku käsittelee PUT-pyynnöt eli tehtävän muokkaamisen
 */
reititin.put("/:id", async (request: Request, response: Response) => {
    try {

        const { id } = request.params;
        const { nimi, tila } = request.body;

        if(!nimi || tila === undefined) {
            throw {
                statusKoodi: 400,
                virheViesti: "Virheellinen sisältö"
            }
        }

        const muokattuTehtava = await tehtavalistaModel.muokkaaTehtava(id, request.body);

        return response.status(200).json(muokattuTehtava);

    } catch (error: any) {
        return response.status(error.statusCode).json(error);
    }
});