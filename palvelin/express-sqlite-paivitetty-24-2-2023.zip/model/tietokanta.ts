import { Tehtava } from "../tyypit";
import path from "path"
import { v4 as uuid } from "uuid";
import sqlite3 from "sqlite3";
import { open, Database } from "sqlite";

/**
 * Luokka, vastaa datan käsittelystä tietokannassa
 */
export default class TehtavalistaTietokantaModel {
    private tietokanta?: Database;

    // Alustetaan luokka
    constructor() {
        this.yhdistaTietokantaan();
    }

    /**
     * Hakee tehtävälistan tietokannasta
     * 
     * @returns tehtävälista
     */
    public haeTehtavalista = async () => {
        const tehtavat = await this.tietokanta?.all("SELECT * FROM tehtavalista");
        console.log(tehtavat);
        return tehtavat;
    }

    /**
      * Luo uuden tehtävän tehtävälistaan
      * 
      * @param nimi 
      * @returns uuden tehtävän
      */
    public async luoTehtava(nimi: string) {
        const uniikkiNimi = await this.tarkistaOnkoNimiKonflikti(nimi);
        if (!uniikkiNimi) {
            throw {
                statusKoodi: 409,
                virheViesti: `Tehtävälista sisältää jo tehtävän nimellä ${nimi}`
            }
        }

        const id = uuid();

        const lause = await this.tietokanta?.prepare(`
            INSERT INTO tehtavalista (id, nimi, tila)
            VALUES (?, ?, ?)
        `)

        await lause?.run(id, nimi, 'Tekemättä');

        /* await this.tietokanta?.exec(`
            INSERT INTO tehtavalista (
                id, nimi, tila
            ) VALUES (
                '${id}', '${nimi}', 'Tekemättä'
            )
        `) */

        const luotuTehtava = await this.etsiTehtava(id)

        return luotuTehtava;
    }

    /**
     * Poista tehtävä
     */
    public async poistaTehtava(id: string) {
        await this.etsiTehtava(id);
        const lause = await this.tietokanta?.prepare(`
            DELETE FROM tehtavalista 
            WHERE id = ?
        `)

        await lause?.run(id);

        /* await this.tietokanta?.exec(`
            DELETE FROM tehtavalista WHERE id = '${id}'
        `) */
    }

    /**
     * Muokkaa tehtävä
     */
    public async muokkaaTehtava(id: string, tehtava: Tehtava) {
        const loydettyTehtava = await this.etsiTehtava(id);
        const uniikkiNimi = await this.tarkistaOnkoNimiKonflikti(tehtava.nimi);

        if(!uniikkiNimi) {
            if (loydettyTehtava.nimi !== tehtava.nimi){
                throw {
                    statusCode: 409,
                    virheViesti: `Tehtävälista sisältää jo tehtävän nimellä ${tehtava.nimi}`
                }
            }
        }

        const lause = await this.tietokanta?.prepare(`
            UPDATE tehtavalista
            SET nimi = ?, tila = ?
            WHERE id = ?
        `)

        await lause?.run(tehtava.nimi, tehtava.tila, id)

        /* await this.tietokanta?.exec(`
            UPDATE tehtavalista
            SET nimi = '${tehtava.nimi}', tila = '${tehtava.tila}'
            WHERE id = '${id}'
        `) */

        const muokattuTehtava = this.etsiTehtava(id);
        return muokattuTehtava;
    }

    /**
     * Etsi yksittäisen tehtävän tehtävälistalta
     */
    public etsiTehtava = async (id: string) => {
        const loydettyTehtava = await this.tietokanta?.get(`SELECT * FROM tehtavalista WHERE id = ?`, id);

        if (!loydettyTehtava) {
            throw {
                statusKoodi: 400,
                virheViesti: `Tehtävää id:llä ${id} ei löytynyt`
            }
        }

        return loydettyTehtava;
    }

    /**
    * Tarkistaa onko nimi jo käytössä, palauttaa true, jos on
    * 
    * @param nimi 
    * @returns true tai false
    */
    private tarkistaOnkoNimiKonflikti = async (nimi: string) => {
        const loytyykoTehtava = await this.tietokanta?.get(`SELECT * FROM tehtavalista WHERE nimi = ?`, nimi)

        return Boolean(!loytyykoTehtava);
    }

    /**
     * Avataan yhteys tietokantaan
     * Luo tietokantatiedoston samaan kansioon modelin kanssa jos sellaista ei vielä ole
     */
    private yhdistaTietokantaan = async () => {
        this.tietokanta = await open({
            filename: path.resolve(__dirname, "tehtavalista.db"),
            driver: sqlite3.Database
        })

        await this.tietokanta.run(`
            CREATE TABLE IF NOT EXISTS tehtavalista (
                id TEXT PRIMARY KEY NOT NULL,
                nimi TEXT NOT NULL UNIQUE,
                tila TEXT NOT NULL
            )
        `)
    }
}