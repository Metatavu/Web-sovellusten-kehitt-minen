export type Tehtava = {
    id: string;
    nimi: string;
    tila: string;
}