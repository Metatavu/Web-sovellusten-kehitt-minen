Tämä on yksinkertainen demo-react-sovellus, käyttäen Vite-työkalua

# Uuden projektin alustus
npm create vite@latest
-> Seuraa ohjeita

# Projektin alustus käyttämään Reactia ja typescriptia
npm create vite@latest "Projektin nimi" -- --template react-ts

# Palvelimen käynnistäminen
npm run dev