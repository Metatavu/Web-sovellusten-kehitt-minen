export interface Tehtava {
    id: number;
    text: string;
}

export class TehtavaListaModel {
    private tehtavat: Tehtava[] = [];

    haeTehtavat(): Tehtava[] {
        return this.tehtavat;
    }

    lisaaTehtava(text: string): void {
        this.tehtavat.push({ id: Date.now(), text })
    } 

}