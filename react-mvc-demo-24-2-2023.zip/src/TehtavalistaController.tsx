import { TehtavaListaModel } from "./models/TehtavalistaModel"
import TehtavaListaView from "./view/TehtavaListaView"

const malli = new TehtavaListaModel();

const TehtavalistaController: React.FC = () => {

  const kasitteleLisays = (text: string) => {
    malli.lisaaTehtava(text);
  }
   
  return (
    <TehtavaListaView
      tehtavat={ malli.haeTehtavat() }
      kasitteleLisays={ kasitteleLisays }
    />
  )
}

export default TehtavalistaController;