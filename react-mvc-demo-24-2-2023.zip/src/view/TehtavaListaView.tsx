import { Delete } from "@mui/icons-material";
import { Box, Button, TextField, List, ListItem, ListItemText, ListItemSecondaryAction, IconButton } from "@mui/material";
import React, { FC, useState } from "react";
import { Tehtava } from "../models/TehtavalistaModel";

interface Props {
    tehtavat: Tehtava[];
    kasitteleLisays: (text: string) => void;
}

const TehtavaListaView: FC<Props> = ({
    tehtavat,
    kasitteleLisays
}) => {
    const [ text, setText ] = useState("");

    const kasitteleTehtavanLisays = () => {
        kasitteleLisays(text)
        setText("");
    }

    return (
        <Box>
            <TextField
                value={ text }
                onChange={ (event: any) => setText(event.target.value) }
                label="Lisää tehtävä"
                variant="outlined"
            />
            <Button
                onClick={kasitteleTehtavanLisays}
                variant="contained" color="primary"
                disabled={!text}
            >
                Lisää tehtävä
            </Button>
            <List>
                { tehtavat.map(tehtava => (
                    <ListItem>
                        <ListItemText primary={tehtava.text} />
                        <ListItemSecondaryAction>
                            <IconButton>
                                <Delete/>
                            </IconButton>
                        </ListItemSecondaryAction>
                    </ListItem>
                ))}
            </List>
        </Box>
    );
}

export default TehtavaListaView; 