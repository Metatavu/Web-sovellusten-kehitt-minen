import React, { useState, FC } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { v4 as uuid } from "uuid";
import ListaScreen from "./screens/ListaScreen";
import LuontiScreen from "./screens/LuontiScreen";
import MuokkausScreen from "./screens/MuokkausScreen";
import PoistoScreen from "./screens/PoistoScreen";
import TilaScreen from "./screens/TilaScreen";

/**
 * TodoAsian tyypitys, olio sisältää vain näitä ominaisuuksia.
 * Uusia olioita luodessa kaikki tyypissa kuvatut ominaisuudet tulee määritellä.
 * Poikkeuksen tekisi sellainen ominaisuus, mikä on valinnainen (esim: tila?: string määrittelee tila-ominaisuuden valinnaiseksi ominaisuudeksi)
 */
interface TodoAsia {
  id: string;
  nimi: string;
  tila: string;
}

/**
 * App komponentti
 * App-komponentti toimii sovelluksen "juurena", josta navigoidaan käyttäjä haluttuihin polkuihin sovelluksen sisällä.
 */
const App: FC = () => {
  const [ todoLista, setTodoLista ] = useState<TodoAsia[]>([]);

  /**
   * BrowserRouter-komponentti "wrappaa" muut komponenti, eli sen ominaisuudet ovat käytössä kaikissa sen sisälle kirjotetuissa komponenteissa.
   * Route määrittelee yhden polun ja elementin mikä siinä polussa esitetään. Elementti voi olla kokonainen näkymä tai yksittäinen komponentti.
   * Komponentteihin välitetään tietoa "propseina". Propsina voidaan välittää myös metodeja.
   */
  return (
    <div>
      <h1>Todo-lista</h1>
      <BrowserRouter>
        <Routes>
          <Route 
            path="/"
            element={ <ListaScreen todoLista={ todoLista } /> }
          />
          <Route 
            path="/uusi"
            element={ <LuontiScreen todoLista={ todoLista } setTodoLista={ setTodoLista }/> }
          />
          <Route 
            path="/muokkaa/:id"
            element={ <MuokkausScreen todoLista={ todoLista } setTodoLista={ setTodoLista }/> }
          />
          <Route 
            path="/poista/:id"
            element={ <PoistoScreen todoLista={ todoLista } setTodoLista={ setTodoLista }/> }
          />
          <Route 
            path="/tila/:id"
            element={ <TilaScreen todoLista={ todoLista } setTodoLista={ setTodoLista }/> }
          />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App;