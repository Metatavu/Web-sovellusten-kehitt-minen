import React, { FC } from "react";
import { useNavigate } from "react-router-dom";
import Lista from "../components/lista";

interface TodoAsia {
    id: string;
    nimi: string;
}

type Props = {
    todoLista: TodoAsia[];
}

/**
 * ListaScreen komponentti
 */
const ListaScreen: FC<Props> = ({
    todoLista
}) => {
    const navigoi = useNavigate()

    const kasittelePoistoNappi = (id: string) => {
        navigoi(`/poista/${id}`)
    }

    const kasitteleMuokkaaNappi = (id: string) => {
        navigoi(`/muokkaa/${id}`)
    }

    const kasitteleOnkoTehtyNappi = (id: string) => {
        navigoi(`/muokkaa/${id}`)
    }

    return (
        <>
            <p>Lisää uusi asia listalle</p>
            <button onClick={ () => navigoi("/uusi") }>Lisää</button>
            <Lista>
                { todoLista.map(asia => {
                    return (
                        <li
                            key={ asia.id }
                            style={{padding: "10px", border: "1px solid black"}}
                        >
                            <p style={{margin:0}}>{ asia.nimi }</p>
                            <button onClick={ () => kasittelePoistoNappi(asia.id) }>Poista</button>
                            <button onClick={ () => kasitteleMuokkaaNappi(asia.id) }>Muokkaa</button>
                            <button onClick={ () => kasitteleOnkoTehtyNappi(asia.id) }>Tekemättä</button>
                        </li>
                    )
                }) }
            </Lista>
        </>
    )
}

export default ListaScreen;