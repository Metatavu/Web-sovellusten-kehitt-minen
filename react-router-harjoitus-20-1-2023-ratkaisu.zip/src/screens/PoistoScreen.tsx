import React, { FC } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * PoistoScreen komponentti
 */
const PoistoScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate();
    const { id } = useParams();

    const poistettavaAsia = todoLista.find(asia => asia.id === id);

    /**
   * Poistaa asian listalta
   */
    const kasittelePoisto = (id: string) => {
        const uusiLista = todoLista.filter(asia => asia.id !== id);

        setTodoLista(uusiLista);
        alert("Poisto onnistui!")
        navigoi("/");
    }

    return (
        <>
            <p>Poistetaanko {poistettavaAsia && poistettavaAsia.nimi}</p>
            <button onClick={() => id && kasittelePoisto(id)}>Poistetaan vaan</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </>
    )
}

export default PoistoScreen;