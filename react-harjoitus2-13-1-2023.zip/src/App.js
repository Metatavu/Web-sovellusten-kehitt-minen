import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      laskunSumma: 0,
      tippi: 0,
      kokonaisSumma: 0
    }
  }

  /**
   * Käsittelee laskun summan muutoksen
   */
  kasitteleLaskunSummanMuutos = (event) => {
    let { value } = event.target;
    
    this.setState({
      laskunSumma: value
    })
  }

  /**
   * Laskee tipin määrän
   */
  laskeTippi = () => {
    let { laskunSumma } = this.state;
    let tipinMaara = laskunSumma * 0.15;

    this.setState({
      tippi: tipinMaara
    })

    this.laskeKokonaisSumma(tipinMaara);
  }

  /**
   * Laskee kokonaissumman
   */
  laskeKokonaisSumma = (tippi) => {
    let { laskunSumma } = this.state;
    let kokonaisSumma = Number(laskunSumma) + Number(tippi);
    console.log(kokonaisSumma)
    this.setState({
      kokonaisSumma: kokonaisSumma
    })
  }

  render() {
    let tulostaKokonaisSumma;

    if (this.state.kokonaisSumma > 0) {
      tulostaKokonaisSumma = (
        <p className="alert alert-success">Kokonaissumma: { this.state.kokonaisSumma }</p>
      );
    }

    return (
      <div className="container">
        <h1>Tippilaskuri</h1>

        <label htmlFor="laskunSumma">Laskun summa (syötä laskun loppusumma)</label>
        <input type="number" name="laskunSumma" className="form-control" onChange={ this.kasitteleLaskunSummanMuutos }/>
        <button className="btn btn-primary mt-1" name="laskeTippi" onClick={ this.laskeTippi }>Laske tippi</button>
        <p>Tipin määrä: { this.state.tippi }</p>
        { tulostaKokonaisSumma }
      </div>
    )
  }
}

export default App;