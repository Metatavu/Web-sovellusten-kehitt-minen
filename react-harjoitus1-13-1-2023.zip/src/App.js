
import React from "react";

class App extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      nimi: "Eetu Lepistö",
      ika: undefined
    }
  }

  kasitteleNimenMuutos = (event) => {
    let { value } = event.target;
    this.setState({
      nimi: value
    });
  }

  kasitteleIanMuutos = (event) => {
    let { value } = event.target;
    this.setState({
      ika: Number(value)
    });
  }

  render() {
    return (
      <>
        <div>
          <h1>Heippa { this.state.nimi }</h1>
          <input name="nimi" type="text" value={ this.state.nimi } onChange={ this.kasitteleNimenMuutos } />
        </div>

        <div>
          <p>Minkä ikäinen olet?</p>
          <input name="ika" type="number" onChange={ this.kasitteleIanMuutos } />
          <h2>{ this.state.nimi } on { this.state.ika }-vuotias.</h2>
        </div>
      </>
    )
  }
}

export default App;