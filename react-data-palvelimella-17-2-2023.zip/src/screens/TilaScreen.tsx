import React, { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * TilaScreen komponentti
 */
const TilaScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate()
    const { id } = useParams();
    // const muokattavaAsia = todoLista.find(asia => asia.id === id);
    const [ uusiTila, setUusiTila ] = useState<string>("")
    const [ muokattavaAsia, setMuokattavaAsia ] = useState<TodoAsia>()

    useEffect(() => {
        haeMuokattavaAsia();
    }, [])

    /**
     * Hakee poistettavan asian palvelimelta
     */
    const haeMuokattavaAsia = async () => {
        try {
            const response = await fetch(`/tehtavalista/${id}`);
            const data = await response.json();

            setMuokattavaAsia(data);
        } catch (error: any) {
            console.error(error);
        }
    }

    const kasitteleTilanMuutos = async (id: string) => {
        if(!uusiTila || !muokattavaAsia) {
            return;
        }
        try {
            await fetch(`/tehtavalista/${id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    nimi: muokattavaAsia.nimi,
                    tila: uusiTila
                })
            });
            navigoi("/");
        } catch (error) {
            console.log(error);
        }
    }
    
    /**
    * Muokkaa asian tilaa
    * Vanha tapa (props)
    */
    /*const kasitteleTilanMuutos = (id: string) => {
        const uusiLista = todoLista.map(asia => {
            if(asia.id === id) {
                asia.tila = tila;
            }

            return asia;
        })
        setTodoLista(uusiLista)
        navigoi("/");
    }*/

    return (
        <div>
            <select defaultValue={ muokattavaAsia?.tila } onChange={ (event) => setUusiTila(event.target.value) }>
                <option selected value="Tekemättä">Tekemättä</option>
                <option value="Tehty">Tehty</option>
            </select>
            <button onClick={() => id && kasitteleTilanMuutos(id)}>Tallenna</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </div>
    )
}

export default TilaScreen;