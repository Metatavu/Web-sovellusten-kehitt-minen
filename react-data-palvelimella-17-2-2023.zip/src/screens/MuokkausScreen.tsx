import React, { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * MuokkausScreen komponentti
 */
const MuokkausScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate()
    const { id } = useParams();
    // const muokattavaAsia = todoLista.find(asia => asia.id === id);
    const [ muokattavaAsia, setMuokattavaAsia ] = useState<TodoAsia>()
    const [ uusiNimi, setUusiNimi ] = useState<string>("")

    useEffect(() => {
        haeMuokattavaAsia();
    }, [])

    /**
     * Hakee poistettavan asian palvelimelta
     */
    const haeMuokattavaAsia = async () => {
        try {
            const response = await fetch(`/tehtavalista/${id}`);
            const data = await response.json();

            setMuokattavaAsia(data);
        } catch (error: any) {
            console.error(error);
        }
    }

    const kasitteleMuokkaus = async (id: string) => {
        if(!uusiNimi || !muokattavaAsia) {
            return;
        }
        try {
            await fetch(`/tehtavalista/${id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    nimi: uusiNimi,
                    tila: muokattavaAsia.tila
                })
            });
            navigoi("/");
        } catch (error) {
            console.log(error);
        }
    }
    
    /**
    * Muokkaa asiaa
    * Vanha tapa (props)
    */
    /*const kasitteleMuokkaus = (id: string) => {
        const uusiLista = todoLista.map(asia => {
            if(asia.id === id && uusiNimi !== "") {
                asia.nimi = uusiNimi;
            }

            return asia;
        })
        setTodoLista(uusiLista)
        alert("Muokkaus onnistui!");
        navigoi("/");
    }*/

    return (
        <div>
            <input defaultValue={ muokattavaAsia?.nimi } onChange={ (event) => setUusiNimi(event.target.value) } />
            <button onClick={() => id && kasitteleMuokkaus(id)}>Tallenna</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </div>
    )
}

export default MuokkausScreen;