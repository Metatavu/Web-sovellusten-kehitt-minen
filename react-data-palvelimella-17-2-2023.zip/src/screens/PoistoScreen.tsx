import React, { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * PoistoScreen komponentti
 */
const PoistoScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate();
    const { id } = useParams();
    const [ poistettavaAsia, setPoistettavaAsia ] = useState<TodoAsia>();

    // const poistettavaAsia = todoLista.find(asia => asia.id === id); Vanha propseihin perustuva tapa

    useEffect(() => {
        haePoistettavaAsia();
    }, [])

    /**
     * Hakee poistettavan asian palvelimelta
     */
    const haePoistettavaAsia = async () => {
        try {
            const response = await fetch(`/tehtavalista/${id}`);
            const data = await response.json();

            setPoistettavaAsia(data);
        } catch (error: any) {
            console.error(error);
        }
    }

    /**
   * Poistaa asian listalta
   * Vanha tapa
   */
    /*const kasittelePoisto = (id: string) => {
        const uusiLista = todoLista.filter(asia => asia.id !== id);

        setTodoLista(uusiLista);
        alert("Poisto onnistui!")
        navigoi("/");
    }*/

    const kasittelePoisto = async (id: string) => {
        try {
            await fetch(`/tehtavalista/${id}`, {
                method: "DELETE"
            })
            navigoi("/");
        } catch (error) {
            console.log(JSON.stringify(error));
        }
    }

    return (
        <>
            <p>Poistetaanko {poistettavaAsia && poistettavaAsia.nimi}</p>
            <button onClick={() => id && kasittelePoisto(id)}>Poistetaan vaan</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </>
    )
}

export default PoistoScreen;