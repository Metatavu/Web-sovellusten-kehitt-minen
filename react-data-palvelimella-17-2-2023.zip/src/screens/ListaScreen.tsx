import React, { FC, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Lista from "../components/lista";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
}

/**
 * ListaScreen komponentti
 */
const ListaScreen: FC<Props> = ({
    todoLista
}) => {
    const navigoi = useNavigate();
    const [ tehtavalista, setTehtavalista ] = useState<TodoAsia[]>([]);

    useEffect(() => {
        haeLista();
    }, [])

    /**
     * Hakee tehtävälistan palvelimelta
     */
    const haeLista = async () => {
        try {
            const response = await fetch("/tehtavalista");
            const data = await response.json();
            console.log(data);
            setTehtavalista(data);
        } catch (error: any) {
            console.error(error);
        }
    }

    /**
     * Käsittele poistonapin klikkaus
     * @param id id
     */
    const kasittelePoistoNappi = (id: string) => {
        navigoi(`/poista/${id}`)
    }

    /**
     * Käsittele muokkausnapin klikkaus
     * @param id id
     */
    const kasitteleMuokkaaNappi = (id: string) => {
        navigoi(`/muokkaa/${id}`)
    }

    /**
     * Käsittele Onko tehty-tekstin klikkaus
     * @param id id
     */
    const kasitteleOnkoTehty = (id: string) => {
        navigoi(`/tila/${id}`)
    }

    return (
        <>
            <p>Lisää uusi asia listalle</p>
            <button onClick={ () => navigoi("/uusi") }>Lisää</button>
            <Lista>
                { tehtavalista.map(asia => {
                    return (
                        <li
                            key={ asia.id }
                            style={{padding: "10px", border: "1px solid black"}}
                        >
                            <p style={{margin:0}}>{ asia.nimi }</p>
                            <button onClick={ () => kasittelePoistoNappi(asia.id) }>Poista</button>
                            <button onClick={ () => kasitteleMuokkaaNappi(asia.id) }>Muokkaa</button>
                            <p
                                style={{
                                    backgroundColor: asia.tila === "Tekemättä" ? "red" : "lightgreen"
                                }}
                                onClick={ () => kasitteleOnkoTehty(asia.id) }
                            >
                                { asia.tila }
                            </p>
                        </li>
                    )
                }) }
            </Lista>
        </>
    )
}

export default ListaScreen;