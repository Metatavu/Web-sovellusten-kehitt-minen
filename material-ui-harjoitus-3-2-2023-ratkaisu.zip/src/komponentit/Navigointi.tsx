import { Button, Stack } from "@mui/material";
import React, { FC } from "react";

const Navigointi: FC = () => {

    return (
        <Stack direction="row" justifyContent="space-between">
            <Button variant="contained">Ensimmäinen linkki</Button>
            <Button variant="outlined">Toinen linkki</Button>
            <Button variant="text">Kolmas linkki</Button>
        </Stack>
    )
}

export default Navigointi;