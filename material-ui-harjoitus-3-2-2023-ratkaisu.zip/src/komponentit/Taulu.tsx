import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import React from "react";

interface LomakeData {
    nimi: string;
    sahkoposti: string;
    ika: number | null;
    ammatti: string;
    lempijuoma: string;
    automerkki: string;
}

interface Props {
    henkiloLista: LomakeData[];
}

const Taulu: React.FC<Props> = ({
    henkiloLista
}) => {

    const renderLista = () => {
        if(!henkiloLista) {
            return;
        }
        const henkilolista = henkiloLista.map(henkilo => {
            return (
                <TableRow
                    key={henkilo.nimi}
                >
                    <TableCell>{ henkilo.nimi }</TableCell>
                    <TableCell>{ henkilo.ika }</TableCell>
                    <TableCell>{ henkilo.sahkoposti }</TableCell>
                    <TableCell>{ henkilo.ammatti }</TableCell>
                    <TableCell>{ henkilo.lempijuoma }</TableCell>
                    <TableCell>{ henkilo.automerkki }</TableCell>
                </TableRow>
            )
        })

        return henkilolista;
    }

    return (
        <TableContainer sx={{ backgroundColor: "white" }}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>Nimi</TableCell>
                        <TableCell>Ikä</TableCell>
                        <TableCell>Sähköposti</TableCell>
                        <TableCell>Ammatti</TableCell>
                        <TableCell>Lempijuoma</TableCell>
                        <TableCell>Automerkki</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    { renderLista() }
                </TableBody>
            </Table>
        </TableContainer>
    )
}

export default Taulu;