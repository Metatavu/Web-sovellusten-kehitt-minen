import { Button, FormControl, FormLabel, MenuItem, Radio, RadioGroup, Stack, TextField, Typography } from '@mui/material';
import FormControlLabel from '@mui/material/FormControlLabel';
import React, { FC } from 'react';

interface Props {
    kasitteleMuutos: (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
    kasitteleLomakkeenLahetys: (event: React.FormEvent<HTMLFormElement>) => void;
}

/**
 * Lomakekomponentti
 */
const Lomake: FC<Props> = ({
    kasitteleMuutos,
    kasitteleLomakkeenLahetys
}) => {
    return (
        <Stack sx={{ backgroundColor: "whitesmoke", padding: 2 }}>
            <Typography variant="h6">Hakulomake</Typography>
            <Stack>
                <form onSubmit={ kasitteleLomakkeenLahetys }>
                    <FormControl fullWidth>
                        <FormLabel>Nimi</FormLabel>
                        <TextField 
                            label="Nimi"
                            name="nimi"
                            defaultValue=""
                            onChange={ (event) => kasitteleMuutos(event) }
                            variant="outlined"
                            sx={{ marginBottom: "10px" }}
                        />
                        <TextField 
                            label="Sähköposti"
                            name="sahkoposti"
                            defaultValue="@"
                            onChange={ (event) => kasitteleMuutos(event) }
                            variant="standard"
                            sx={{ marginBottom: "10px" }}
                        />
                        <TextField 
                            label="Automerkki"
                            name="automerkki"
                            defaultValue=""
                            onChange={ (event) => kasitteleMuutos(event) }
                            variant="outlined"
                            sx={{ marginBottom: "10px" }}
                        />
                    </FormControl>

                    <FormControl sx={{ width: "300px" }}>
                        <TextField
                            type="number"
                            label="Ikä"
                            name="ika"
                            onChange={ (event) => kasitteleMuutos(event) }
                            variant='outlined'
                            sx={{ marginBottom: "10px" }}
                        />
                        <TextField
                            select
                            label="Valitse ammatti"
                            name="ammatti"
                            onChange={ (event) => kasitteleMuutos(event) }
                            variant='outlined'
                            sx={{ marginBottom: "10px" }}
                        >
                            <MenuItem value="">Valitse ammatti</MenuItem>
                            <MenuItem value="kokki">Kokki</MenuItem>
                            <MenuItem value="autonkuljettaja">Autonkuljettaja</MenuItem>
                            <MenuItem value="avaruuscowboy">Avaruus-Cowboy</MenuItem>
                        </TextField>
                    </FormControl>
                    <FormControl fullWidth>
                        <FormLabel>Lempijuoma</FormLabel>
                        <RadioGroup
                            name= "lempijuoma"
                            row
                            onChange={ (event) => kasitteleMuutos(event) }
                            sx={{ marginBottom: "40px" }}
                        >
                            <FormControlLabel value="kahvi" control={ <Radio /> } label="Kahvi"/>
                            <FormControlLabel value="tee" control={ <Radio /> } label="Tee"/>
                            <FormControlLabel value="maito" control={ <Radio /> } label="Maito"/>
                        </RadioGroup>
                    </FormControl>
                    <Button type="submit" variant="contained" color="primary">
                        Lähetä vastaus
                    </Button>
                </form>
            </Stack>
        </Stack>
    );
}

export default Lomake;