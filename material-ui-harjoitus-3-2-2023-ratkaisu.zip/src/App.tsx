import { Box, Container, FormControlLabel, Stack, Switch } from '@mui/material';
import Typography from '@mui/material/Typography';
import React, { FC } from 'react';
import Footer from './komponentit/Footer';
import Header from './komponentit/Header';
import Lomake from './komponentit/Lomake';
import Navigointi from './komponentit/Navigointi';
import Taulu from './komponentit/Taulu';

interface LomakeData {
  nimi: string;
  sahkoposti: string;
  ika: number | null;
  ammatti: string;
  lempijuoma: string;
  automerkki: string;
}

const App: FC = () => {
  const [ naytaLomake, setNaytaLomake ] = React.useState(true);
  const [ henkiloLista, setHenkilolista ] = React.useState<LomakeData[]>([])
  const [ lomakeData, setLomakeData ] = React.useState<LomakeData>({
    nimi: "",
    sahkoposti: "",
    ika: null,
    ammatti: "",
    lempijuoma: "",
    automerkki: ""
  });

  const kasitteleNaytaLomakeMuutos = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNaytaLomake(event.target.checked)
  }

  const kasitteleMuutos = (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target;

    setLomakeData({ ...lomakeData, [name]: value });
  }

  const kasitteleLomakkeenLahetys = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!lomakeData) {
      return;
    }

    let uusiHenkilo = {
      nimi: lomakeData.nimi,
      sahkoposti: lomakeData.sahkoposti,
      ika: lomakeData.ika,
      ammatti: lomakeData.ammatti,
      lempijuoma: lomakeData.lempijuoma,
      automerkki: lomakeData.automerkki
    }

    setHenkilolista([ ...henkiloLista, uusiHenkilo ]);
    setNaytaLomake(false);
  }

  const renderVipu = () => {
    return (
      <FormControlLabel
        control= {
          <Switch
            checked={ naytaLomake }
            onChange={ kasitteleNaytaLomakeMuutos }
          />
        }
        label={ "Näytä lomake" }
      />
    )
  }

  return (
    <Container>
      <Stack
        sx={{
          backgroundColor: "lightgrey",
          minHeight: "100vh",
          paddingRight: 2,
          paddingLeft: 2
        }}
        spacing={ 2 }
      >
        <Header>
          <Navigointi/>
        </Header>
        <Stack sx={{ backgroundColor: "lightgreen", minHeight: "600px", padding: 2 }}>
          <Box sx={{ padding: 2 }}>
            <Typography variant='h3'>Tähän tulostetaan lomake</Typography>
            { renderVipu() }
            { naytaLomake === true
            ? <Lomake kasitteleMuutos={ kasitteleMuutos } kasitteleLomakkeenLahetys={ kasitteleLomakkeenLahetys } /> 
            : <Taulu henkiloLista={ henkiloLista }/> }
          </Box>
        </Stack>
        <Footer/>
      </Stack>
    </Container>
  );
}

export default App;
