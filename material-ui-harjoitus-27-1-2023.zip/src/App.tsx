import { Box, Container, Stack } from '@mui/material';
import Typography from '@mui/material/Typography';
import React, { FC } from 'react';
import Footer from './komponentit/Footer';
import Header from './komponentit/Header';
import Lomake from './komponentit/Lomake';

const App: FC = () => {
  return (
    <Container>
      <Stack
        sx={{
          backgroundColor: "lightgrey",
          minHeight: "100vh",
          paddingRight: 2,
          paddingLeft: 2
        }}
        spacing={ 2 }
      >
        <Header/>
        <Stack sx={{ backgroundColor: "lightgreen", minHeight: "600px", padding: 2 }}>
          <Box sx={{ padding: 2 }}>
            <Typography variant='h3'>Tähän tulostetaan lomake</Typography>
            <Lomake />
          </Box>
        </Stack>
        <Footer/>
      </Stack>
    </Container>
  );
}

export default App;
