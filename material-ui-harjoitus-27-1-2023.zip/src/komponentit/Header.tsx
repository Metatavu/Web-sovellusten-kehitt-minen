import { AppBar, Box, Stack, Typography } from '@mui/material';
import React, { FC } from 'react';

const Header: FC = () => {
    return (
        <Stack sx={{ marginTop: 2 }} alignItems="center">
            <AppBar position="static">
                <Box sx={{ backgroundColor: "lightblue", padding: "5px" }}>
                    <Typography variant='h2'>Tämä on header-komponentti</Typography>
                </Box>
            </AppBar>
        </Stack>
    );
}

export default Header