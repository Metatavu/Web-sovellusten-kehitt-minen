import { Stack, Typography } from '@mui/material';
import React, { FC } from 'react';

const Footer: FC = () => {
    return (
        <Stack
            sx={{
                backgroundColor:"lightyellow",
                minHeight: "50px"
            }}
            alignItems="center"
        >
          <Typography variant='subtitle1'>Tämä on footer-komponentti</Typography>
        </Stack>
    );
}

export default Footer;