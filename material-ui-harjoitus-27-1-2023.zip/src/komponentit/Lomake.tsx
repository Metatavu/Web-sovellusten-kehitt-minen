import { AppBar, Box, Button, FormControl, FormLabel, MenuItem, RadioGroup, Stack, TextField, Typography } from '@mui/material';
import React, { FC } from 'react';

/**
 * Lomakekomponentti
 */
const Lomake: FC = () => {
    return (
        <Stack sx={{ backgroundColor: "whitesmoke", padding: 2 }}>
            <Typography variant="h6">Hakulomake</Typography>
            <Stack>
                <form>
                    <FormControl fullWidth>
                        <FormLabel>Nimi</FormLabel>
                        <TextField 
                            label="Nimi"
                            name="nimi"
                            defaultValue=""
                            onChange={ (event) => console.log(event.target.value) }
                            variant="outlined"
                            sx={{ marginBottom: "10px" }}
                        />
                        <TextField 
                            label="Sähköposti"
                            name="sahkoposti"
                            defaultValue="@"
                            onChange={ (event) => console.log(event.target.value) }
                            variant="standard"
                            sx={{ marginBottom: "10px" }}
                        />
                    </FormControl>

                    <FormControl sx={{ width: "300px" }}>
                        <TextField
                            type="number"
                            label="Ikä"
                            name="ika"
                            variant='outlined'
                            sx={{ marginBottom: "10px" }}
                        />
                        <TextField
                            select
                            label="Valitse ammatti"
                            name="ammatti"
                            variant='outlined'
                            sx={{ marginBottom: "10px" }}
                        >
                            <MenuItem value="">Valitse ammatti</MenuItem>
                            <MenuItem value="kokki">Kokki</MenuItem>
                            <MenuItem value="autonkuljettaja">Autonkuljettaja</MenuItem>
                            <MenuItem value="avaruuscowboy">Avaruus-Cowboy</MenuItem>
                        </TextField>
                    </FormControl>
                    <FormControl fullWidth>
                        <FormLabel>Lempijuoma</FormLabel>
                        <RadioGroup>
                            
                        </RadioGroup>
                    </FormControl>
                    <Button type="submit" variant="contained" color="primary">
                        Lähetä vastaus
                    </Button>
                </form>
            </Stack>
        </Stack>
    );
}

export default Lomake;