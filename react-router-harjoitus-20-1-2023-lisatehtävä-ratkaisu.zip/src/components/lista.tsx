/**
 * Komponentin ominaisuudet
 */
interface Props {
    children: React.ReactNode;
}

/**
 * Lista komponentti
 */
const Lista: React.FC<Props> = ({ children }) => {
    return (
        <ul style={{ width: "250px" }}>
            { children }
        </ul>
    )
}

export default Lista;