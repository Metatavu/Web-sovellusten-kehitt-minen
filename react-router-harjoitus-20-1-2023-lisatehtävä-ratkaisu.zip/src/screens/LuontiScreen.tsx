import React, { FC, useState } from "react";
import { useNavigate } from "react-router-dom";
import { v4 as uuid } from "uuid";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * LuontiScreen komponentti
 */
const LuontiScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate()
    const [ uusiNimi, setUusiNimi ] = useState<string>("")
    
    /**
    * Luo asia
    */
    const kasitteleLuonti = () => {
        if (!uusiNimi) {
            return;
        }
        const onDuplikaatti = todoLista.find(asia => asia.nimi === uusiNimi);
        if (onDuplikaatti) {
            alert("Yritä keksiä uniikki nimi.");
        } else {
            const uusiLista = [...todoLista];
            const uusiAsia: TodoAsia = {id: uuid(), nimi: uusiNimi, tila: "Tekemättä"}
            uusiLista.push(uusiAsia);
            setTodoLista(uusiLista)
            alert("Uuden asian lisäys onnistui!")
            navigoi("/");
        }
    }

    return (
        <div>
            <input onChange={ (event) => setUusiNimi(event.target.value) } />
            <button onClick={ kasitteleLuonti }>Luo uusi asia</button>
            <button onClick={() => navigoi("/")}>Peruuta</button>
        </div>
    )
}

export default LuontiScreen;