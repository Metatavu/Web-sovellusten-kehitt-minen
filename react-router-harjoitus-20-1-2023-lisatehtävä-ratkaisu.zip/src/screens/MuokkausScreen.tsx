import React, { FC, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * MuokkausScreen komponentti
 */
const MuokkausScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate()
    const { id } = useParams();
    const muokattavaAsia = todoLista.find(asia => asia.id === id);
    const [ uusiNimi, setUusiNimi ] = useState<string>("")
    
    /**
    * Muokkaa asiaa
    */
    const kasitteleMuokkaus = (id: string) => {
        const uusiLista = todoLista.map(asia => {
            if(asia.id === id && uusiNimi !== "") {
                asia.nimi = uusiNimi;
            }

            return asia;
        })
        setTodoLista(uusiLista)
        alert("Muokkaus onnistui!");
        navigoi("/");
    }

    return (
        <div>
            <input defaultValue={ muokattavaAsia?.nimi } onChange={ (event) => setUusiNimi(event.target.value) } />
            <button onClick={() => id && kasitteleMuokkaus(id)}>Tallenna</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </div>
    )
}

export default MuokkausScreen;