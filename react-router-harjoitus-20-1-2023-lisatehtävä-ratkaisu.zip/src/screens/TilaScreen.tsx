import React, { FC, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

interface TodoAsia {
    id: string;
    nimi: string;
    tila: string;
}

type Props = {
    todoLista: TodoAsia[];
    setTodoLista: (lista: TodoAsia[]) => void;
}

/**
 * TilaScreen komponentti
 */
const TilaScreen: FC<Props> = ({
    todoLista,
    setTodoLista
}) => {
    const navigoi = useNavigate()
    const { id } = useParams();
    const muokattavaAsia = todoLista.find(asia => asia.id === id);
    const [ tila, setUusiTila ] = useState<string>("")
    
    /**
    * Muokkaa asian tilaa
    */
    const kasitteleTilanMuutos = (id: string) => {
        const uusiLista = todoLista.map(asia => {
            if(asia.id === id) {
                asia.tila = tila;
            }

            return asia;
        })
        setTodoLista(uusiLista)
        navigoi("/");
    }

    return (
        <div>
            <select defaultValue={ muokattavaAsia?.tila } onChange={ (event) => setUusiTila(event.target.value) }>
                <option selected value="Tekemättä">Tekemättä</option>
                <option value="Tehty">Tehty</option>
            </select>
            <button onClick={() => id && kasitteleTilanMuutos(id)}>Tallenna</button>
            <button onClick={() => navigoi("/")}>Palaa listaukseen</button>
        </div>
    )
}

export default TilaScreen;