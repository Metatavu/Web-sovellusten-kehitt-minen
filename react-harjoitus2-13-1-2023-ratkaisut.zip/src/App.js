import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      laskunSumma: 0,
      tippi: 0,
      kokonaisSumma: 0,
      virhe: false
    }
  }

  /**
   * Käsittelee laskun summan muutoksen
   */
  kasitteleLaskunSummanMuutos = (event) => {
    let { value } = event.target;
    this.setState({virhe: false})

    if (value < 0 || value > 1000) {
      this.setState({
        virhe: true
      })
    } else {
      this.setState({
        laskunSumma: value
      })
    }
  }

  /**
   * Laskee tipin määrän
   */
  laskeTippi = (event) => {
    let { name } = event.target;
    let { laskunSumma, virhe } = this.state;
    let tipinMaara = laskunSumma * (name === "tippi10" ? 0.1 : 0.2 );

    if (virhe === true) {
      return;
    }

    this.setState({
      tippi: tipinMaara.toFixed(2)
    })

    this.laskeKokonaisSumma(tipinMaara);
  }

  /**
   * Laskee kokonaissumman
   */
  laskeKokonaisSumma = (tippi) => {
    let { laskunSumma } = this.state;
    let kokonaisSumma = Number(laskunSumma) + Number(tippi);

    this.setState({
      kokonaisSumma: kokonaisSumma.toFixed(2)
    })
  }

  render() {
    let tulostaKokonaisSumma;
    let tulostaVirhe;

    if (this.state.kokonaisSumma > 0 && this.state.virhe === false) {
      tulostaKokonaisSumma = (
        <p className="alert alert-success">Kokonaissumma: { this.state.kokonaisSumma }</p>
      );
    }

    if (this.state.virhe === true) {
      tulostaVirhe = (
        <p className="alert alert-danger">Virhe: syötä summa posiitivisina numeroina, esim. 15.50. Summa ei saa olla yli 1000</p>
      );
    }

    return (
      <div className="container">
        <h1>{ this.props.otsikko }</h1>

        <label htmlFor="laskunSumma">Laskun summa (syötä laskun loppusumma)</label>
        <input type="number" name="laskunSumma" className="form-control" onChange={ this.kasitteleLaskunSummanMuutos }/>
        <button className="btn btn-primary mt-1" name="tippi10" onClick={ this.laskeTippi }>Tippi 10%</button>
        <button className="btn btn-success mt-1" name="tippi20" onClick={ this.laskeTippi }>Tippi 20%</button>
        <p>Tipin määrä: { this.state.tippi }</p>
        { tulostaKokonaisSumma }
        { tulostaVirhe }
      </div>
    )
  }
}

export default App;